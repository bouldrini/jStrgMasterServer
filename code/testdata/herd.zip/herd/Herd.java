package herd;

/**
 * Created by Student on 09.11.2015.
 */
public class Herd {

    private int hotplaces;
    private int temp_hotplace[];
    private boolean oven;
    private int temp_oven;

    public Herd(int _herdplatten, boolean _ofen) {
        this.hotplaces = _herdplatten;
        this.oven = _ofen;
        this.temp_hotplace = new int[_herdplatten];
        for (int index = 0 ; index < _herdplatten ; index++) {
            temp_hotplace[index] = 0;
        }
    }
    @Override
    public String toString() {
        StringBuilder returnstring = new StringBuilder();
        int index = 1;
        for (int iterator : temp_hotplace) {
            returnstring.append("Platte" + index + ": " + iterator + "\t");
            index++;
        }
        returnstring.append("\n");
        if (oven) {
            returnstring.append("Ofen: " + temp_oven + "\n");
        }

        return returnstring.toString();
    }

    public int getHotplaces() {
        return hotplaces;
    }

    public int[] getTemp_hotplace() {
        return temp_hotplace;
    }

    public void setTemp_platten(int platte, int temp) {
        this.temp_hotplace[platte] = temp;
    }

    public boolean getOven() {
        return oven;
    }

    public int getTemp_oven() {
        return temp_oven;
    }

    public void setTemp_oven(int temp_oven) {
        this.temp_oven = temp_oven;
    }
}
