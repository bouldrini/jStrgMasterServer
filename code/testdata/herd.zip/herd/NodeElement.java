package herd;

/**
 * Created by Student on 16.11.2015.
 */
public class NodeElement {
    public NodeElement(Herd _herd) {
        this.content = _herd;
    }

    public NodeElement getNextElement() {
        return nextElement;
    }

    public void setNextElement(NodeElement nextElement) {
        this.nextElement = nextElement;
    }

    public NodeElement nextElement;
    public Herd content;
}
