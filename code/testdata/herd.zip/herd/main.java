package herd;

/**
 * Created by Student on 09.11.2015.
 */

public class main {

    public static void main(String[] args) {
        NodeList my_node_list = new NodeList();
        Herd my_herd;
        for (int i = 0; i<100 ; i++) {
            my_herd = new Herd(4, true);
            my_herd.setTemp_platten(2, 60);
            my_herd.setTemp_oven(200);
            my_node_list.insertElement(my_herd);
        }


        System.out.println(my_node_list);
    }
}
