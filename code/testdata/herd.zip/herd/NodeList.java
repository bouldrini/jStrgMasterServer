package herd;

/**
 * Created by Student on 16.11.2015.
 */
public class NodeList {
    public void NodeList() {
        this.listsize = 0;
    }
    private NodeElement lastElement;
    private int listsize;
    private NodeElement firstElement;

    public void insertElement(Herd _herd) {
        NodeElement insertion = new NodeElement(_herd);
        if (this.getLastElement() == null) {
            this.firstElement = insertion;
            this.lastElement = insertion;
        } else {
            this.lastElement.setNextElement(insertion);
            this.setLastElement(insertion);
        }
        this.listsize += 1;
    }

    @Override
    public String toString() {
        if ( this.getFirstElement() == null) {
            return "List empty";
        }
        NodeElement current_element = this.getFirstElement();
        StringBuilder returnstring = new StringBuilder();
        returnstring.append(this.getListsize() + " Objects found\n\n");
        int nr = 0;
        while ( current_element != null ) {
            nr++;
            returnstring.append("<-- Object Nr:" + nr + "-->\n"+ current_element.content);
            current_element = current_element.getNextElement();
        }
        return returnstring.toString();
    }

    public void printList() {

    }

    public int getListsize() {
        return listsize;
    }

    private void setListsize(int listsize) {
        this.listsize = listsize;
    }

    public NodeElement getFirstElement() {
        return firstElement;
    }

    private void setFirstElement(NodeElement firstElement) {
        this.firstElement = firstElement;
    }

    public NodeElement getLastElement() {
        return lastElement;
    }

    private void setLastElement(NodeElement lastElement) {
        this.lastElement = lastElement;
    }
}
